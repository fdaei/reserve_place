<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    use HasFactory;
    protected $fillable=[
        "name"
    ];

    public function provinces()
    {
        return $this->hasMany(Province::class);
    }

    public function friends()
    {
        return $this->hasMany(Friend::class);
    }
}
