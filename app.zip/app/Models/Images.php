<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Images extends Model
{
    use HasFactory;
    protected $fillable=[
        "url",
        "tour_id",
        "residence_id",
        "store_id",
        "friend_id",
    ];
}
